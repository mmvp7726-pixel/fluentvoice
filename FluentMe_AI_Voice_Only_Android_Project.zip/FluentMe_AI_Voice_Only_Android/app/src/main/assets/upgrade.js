'use strict';
// FluentMe Smart Studio extension. No external AI or hidden scoring is claimed.
// Works with the original local-first app and its existing storage.
const placementQuestions = [
  {q:'She ___ from Galle.',choices:['am','is','are'],right:1,why:'She → is.'},
  {q:'Yesterday, I ___ English.',choices:['study','studied','studies'],right:1,why:'Yesterday → past simple: studied.'},
  {q:'There ___ three books on my desk.',choices:['is','are','be'],right:1,why:'Plural noun → there are.'},
  {q:'I have been learning English ___ January.',choices:['for','since','at'],right:1,why:'Since + starting point.'},
  {q:'If I have time tomorrow, I ___ you.',choices:['call','will call','called'],right:1,why:'First conditional: if + present, will + verb.'},
  {q:'The report ___ by the accountant yesterday.',choices:['prepared','was prepared','is preparing'],right:1,why:'Passive past: was + past participle.'},
  {q:'By the time I arrived, the meeting ___.',choices:['had started','has started','starts'],right:0,why:'An earlier past action may use past perfect.'},
  {q:'Which sentence is most natural?',choices:['I look forward to meet you.','I look forward to meeting you.','I look forward meeting you.'],right:1,why:'Look forward to + -ing.'},
  {q:'She suggested that we ___ the figures again.',choices:['checks','check','checking'],right:1,why:'Suggest that + base form in this formal construction.'},
  {q:'Choose the clearest professional sentence.',choices:['Despite the delay, we completed the report.','Despite of delay, we completed the report.','Although the delay, we completed the report.'],right:0,why:'Despite + noun phrase works here.'}
];
const careerScenes={
  interview:[
    ['Tell me about yourself.','I am a commerce student who enjoys learning accounting and improving my communication skills.'],
    ['Why do you want this role?','I want to gain practical experience while contributing to the team and developing my skills.'],
    ['How do you handle a difficult task?','I divide the task into smaller steps and ask for clarification when necessary.']
  ],
  accounting:[
    ['Explain why a business prepares a cash flow statement.','A cash flow statement explains cash movements from operating, investing and financing activities.'],
    ['Summarize the difference between profit and cash.','Profit is calculated using accrual accounting, but cash reflects actual money received and paid.'],
    ['Describe a simple financial result to your manager.','Revenue increased this month, while expenses remained relatively stable.']
  ],
  meeting:[
    ['Politely disagree with a suggestion.','I see your point, but could we consider another approach?'],
    ['Ask someone to explain an unfamiliar term.','Could you clarify that term and give an example, please?'],
    ['Summarize the next action.','I will prepare the draft report and share it before our next meeting.']
  ],
  presentation:[
    ['Open a short presentation confidently.','Good morning everyone. Today I will explain three key findings from our analysis.'],
    ['Introduce a chart in your slides.','As you can see in this chart, sales increased steadily over the last three months.'],
    ['Conclude your presentation.','To summarize, these results highlight three important opportunities. Thank you for listening.']
  ]
};
let assessing=false,assessIndex=0,assessRight=0,assessChosen=false,assessLevel='A1';
let mistakeCursor=0,mistakeVisible=false,careerCursor=0;
function recommendLevel(right){return right<=3?'A1':right<=6?'A2':right<=8?'B1':'B2'}
function assessRender(){
  const q=placementQuestions[assessIndex];
  $('assessQuestion').textContent=`${assessIndex+1}/10 · ${q.q}`;
  $('assessStatus').textContent=`${assessIndex+1}/10`;
  $('assessOptions').replaceChildren();
  q.choices.forEach((s,i)=>{let b=document.createElement('button');b.className='qoption';b.textContent=s;
    b.onclick=()=>{if(assessChosen)return;assessChosen=true;if(i===q.right)assessRight++;
      $('assessOptions').querySelectorAll('button').forEach((x,k)=>{x.disabled=true;if(k===q.right)x.classList.add('good');else if(k===i)x.classList.add('bad')});
      $('assessFeedback').textContent=`${i===q.right?'✓ Correct.':'Try again when you review.'} ${q.why}`;
      $('assessStart').textContent=assessIndex===placementQuestions.length-1?'See my result →':'Next question →';
      $('assessStart').disabled=false;
    };$('assessOptions').appendChild(b)});
  $('assessStart').disabled=true;
  $('assessApply').classList.add('hide');
}
function assessFinish(){
  assessing=false;assessLevel=recommendLevel(assessRight);
  data.assessment={correct:assessRight,total:placementQuestions.length,suggested:assessLevel,date:dateKey()};
  save();
  $('assessStatus').textContent='CHECK COMPLETE';
  $('assessQuestion').textContent=`${assessRight}/10 answers correct. Suggested starting level: ${assessLevel}`;
  $('assessOptions').replaceChildren();
  $('assessFeedback').textContent='This is only a short grammar check. Real spoken fluency requires listening and live conversation, so this is not a certified CEFR rating.';
  $('assessStart').textContent='Retake level check';$('assessStart').disabled=false;
  $('assessApply').textContent=`Set my level to ${assessLevel}`;$('assessApply').classList.remove('hide');renderSmart();
}
function beginOrNextAssessment(){
  if(!assessing){assessing=true;assessIndex=0;assessRight=0;assessChosen=false;assessRender();return}
  if(!assessChosen)return;
  assessIndex++;assessChosen=false;
  if(assessIndex>=placementQuestions.length)assessFinish();else assessRender();
}
function nextMistake(){
 const corrections=data.corrections||[];
 $('mistakeCount').textContent=`${corrections.length} SAVED`;
 $('mistakeAnswer').classList.add('hide');mistakeVisible=false;
 if(!corrections.length){$('mistakePrompt').textContent='No mistakes saved yet. Try a guided conversation. The coach notices a few common errors.';$('mistakeNote').textContent='Rule-based corrections are limited. They do not catch all mistakes.';return}
 const c=corrections[mistakeCursor%corrections.length];
 $('mistakePrompt').textContent=`Try correcting this sentence:\n“${c.original}”`;
 $('mistakeNote').textContent=`Saved ${c.date||'recently'} · Reviewed ${c.reviewCount||0} time(s)`;
}
function currentMistake(){return data.corrections?.[mistakeCursor%(data.corrections?.length||1)]}
function revealMistake(){const c=currentMistake();if(!c)return toast('No corrections to review yet.');
 $('mistakeAnswer').textContent=`✓ ${c.correct}\n🇱🇰 ${c.reason}`;$('mistakeAnswer').classList.remove('hide');mistakeVisible=true;say(c.correct);
}
function markMistakeReviewed(){const c=currentMistake();if(!c)return toast('Try the guided coach first.');if(!mistakeVisible)return toast('Reveal the correction before reviewing.');
 c.reviewCount=(c.reviewCount||0)+1;c.lastReviewed=dateKey();const dt=new Date();dt.setDate(dt.getDate()+Math.min(14,2**Math.min(3,c.reviewCount-1)));c.nextReview=dateKey(dt);save();toast('Saved review. Keep practising in your own time.');mistakeCursor++;nextMistake();
}
function currentCareer(){let kind=$('careerScene').value;return careerScenes[kind][careerCursor%careerScenes[kind].length]}
function careerRender(){let [q]=currentCareer();$('careerPrompt').textContent=q;$('careerFeedback').textContent='Listen to a natural example, then answer in your own words.'}
function careerSpeak(){const [,sample]=currentCareer();say(sample);}
function careerRepeat(){const [,sample]=currentCareer();speakInto(transcript=>{
 let match=compareSpeech(sample,transcript);let d=getDay();d.career=(d.career||0)+1;activity('listening');markTaskFor('listening');
 $('careerFeedback').textContent=`You said: “${transcript}”\nWord recognition overlap with the sample: ${match}%. Your answer can be different from the example and still be correct. This is not pronunciation scoring.`;
 toast('Nice effort! You practised workplace English.');
});}
function addCareerToCoach(){
 conversations['Career English']=Object.values(careerScenes).flat().map(x=>x[0]);
 let chip=document.createElement('button');chip.className='chip';chip.textContent='💼 Career English';chip.onclick=()=>{topic='Career English';document.querySelectorAll('#topics .chip').forEach(x=>x.classList.toggle('active',x===chip));resetChat()};
 $('topics').appendChild(chip);
}
function suggestedAction(){
 const all=Object.values(data.days),totalGrammar=all.reduce((s,d)=>s+(d.grammar||0),0),totalCorrect=all.reduce((s,d)=>s+(d.correct||0),0),talk=all.reduce((s,d)=>s+(d.chats||0),0);
 const date=dateKey(),due=words.filter(w=>!data.wordProgress[w.word] || data.wordProgress[w.word].nextDue<=date).length;
 if(!data.assessment)return ['Start with a short level check','A few questions help choose your starting difficulty.','assessment'];
 if(talk<3)return ['Speak for a few minutes','You have fewer than three saved speaking attempts. Short conversations build confidence.','speaking'];
 if(totalGrammar>=5&&totalCorrect/totalGrammar<.7)return ['Practise grammar with feedback',`${totalCorrect}/${totalGrammar} grammar answers correct so far. Review one topic at a time.`,'grammar'];
 if(due>3)return ['Review words before learning more',`${due} vocabulary words are new or ready for review.`,'vocab'];
 if(data.corrections?.length)return ['Review one correction','Your personal mistake notebook contains corrections worth revisiting.','mistake'];
 return ['Try a career conversation','You have practised the basics. Try using English in a real-world situation.','career'];
}
function renderMetrics(){
 const all=Object.values(data.days),g=all.reduce((s,d)=>s+(d.grammar||0),0),correct=all.reduce((s,d)=>s+(d.correct||0),0),s=all.reduce((n,d)=>n+(d.chats||0),0),career=all.reduce((n,d)=>n+(d.career||0),0),wordsReviewed=Object.values(data.wordProgress).reduce((n,x)=>n+(x.times||0),0);
 const values=[['Grammar quiz accuracy',g?Math.round(100*correct/g)+'%':'—',`${correct} correct / ${g} attempts`],['Speaking attempts',String(s),`Voice or typed replies (not hours spoken)`],['Word review successes',String(wordsReviewed),'Self-reported remembered words'],['Career speaking attempts',String(career),'Speech recognizer practice']];
 $('skillMetrics').replaceChildren();values.forEach(([label,value,detail])=>{let b=document.createElement('div');b.className='skillMetric';let x=document.createElement('small');x.textContent=label;let v=document.createElement('strong');v.textContent=value;let n=document.createElement('small');n.textContent=detail;b.append(x,v,n);$('skillMetrics').appendChild(b)})
}
function renderSmart(){
 const [title,reason,action]=suggestedAction();$('smartAdvice').textContent=title;$('smartWhy').textContent=reason;$('smartAction').dataset.act=action;
 if(!assessing){if(data.assessment){$('assessStatus').textContent=`LAST: ${data.assessment.correct}/10`;$('assessQuestion').textContent=`Your last suggested starting level: ${data.assessment.suggested}`;$('assessFeedback').textContent='Recheck your level after a few weeks of learning.';}else{$('assessStatus').textContent='NOT TAKEN';$('assessQuestion').textContent='Ready for your first level check?'}}
 nextMistake();careerRender();renderMetrics();
}
function smartAction(){let a=$('smartAction').dataset.act;
 if(a==='assessment'){beginOrNextAssessment();$('assessQuestion').scrollIntoView({block:'center',behavior:'smooth'})}
 else if(a==='mistake'){$('mistakePrompt').scrollIntoView({block:'center',behavior:'smooth'})}
 else if(a==='career'){$('careerPrompt').scrollIntoView({block:'center',behavior:'smooth'})}
 else if(a==='speaking'){go('coach')}
 else{go('practice');selectPractice(a)}
}
function visitSmart(){go('smart');renderSmart()}
function initializeUpgrade(){
 // Existing 35-minute profiles can be changed in Settings. New profiles default to 60.
 if(!data.assessment)data.assessment=null;
 applyLearningPlan();renderHome();renderTimer();
 $('smartHomeBtn').onclick=visitSmart;$('careerHomeBtn').onclick=()=>{visitSmart();$('careerPrompt').scrollIntoView({block:'center',behavior:'smooth'})};
 $('assessStart').onclick=beginOrNextAssessment;
 $('assessApply').onclick=()=>{data.profile.level=assessLevel;save();renderSettings();toast('Your suggested level was saved. You can change it later in Settings.')};
 $('mistakeReveal').onclick=revealMistake;
 $('mistakeReviewed').onclick=markMistakeReviewed;
 $('mistakeNext').onclick=()=>{if(!data.corrections.length)return;mistakeCursor++;nextMistake()};
 $('careerScene').onchange=()=>{careerCursor=0;careerRender()};
 $('careerListen').onclick=careerSpeak;
 $('careerVoice').onclick=careerRepeat;
 $('careerNext').onclick=()=>{careerCursor++;careerRender()};
 $('careerCoach').onclick=()=>{topic='Career English';go('coach');document.querySelectorAll('#topics .chip').forEach(c=>c.classList.toggle('active',c.textContent.includes('Career English')));resetChat()};
 $('smartAction').onclick=smartAction;
 document.querySelectorAll('[data-go="smart"]').forEach(b=>b.addEventListener('click',renderSmart));
 addCareerToCoach();renderSmart();
 // Rebuild recommendations when learner changes tabs; other screens remain functional.
}
initializeUpgrade();
