package com.fluentme.coach;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import java.util.Calendar;

public final class PracticeAlarm extends BroadcastReceiver {
    private static final String CHANNEL="daily_english";
    private static final String PREFS="fluentme_reminders";
    private static final int REQUEST=779;
    public static void createChannel(Context context){
        if (Build.VERSION.SDK_INT>=26){
            NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            manager.createNotificationChannel(new NotificationChannel(CHANNEL,"English daily practice",NotificationManager.IMPORTANCE_DEFAULT));
        }
    }
    private static PendingIntent pending(Context ctx){
        Intent intent=new Intent(ctx,PracticeAlarm.class);
        intent.setAction("com.fluentme.coach.DAILY_REMINDER");
        return PendingIntent.getBroadcast(ctx,REQUEST,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    public static void setDaily(Context ctx,String time){
        if(time==null||!time.matches("([01]\\d|2[0-3]):[0-5]\\d"))throw new IllegalArgumentException("Invalid time");
        ctx.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putBoolean("enabled",true).putString("time",time).apply();
        schedule(ctx,time);
    }
    private static void schedule(Context ctx,String time){
        String[] a=time.split(":");
        Calendar when=Calendar.getInstance();
        when.set(Calendar.HOUR_OF_DAY,Integer.parseInt(a[0]));when.set(Calendar.MINUTE,Integer.parseInt(a[1]));
        when.set(Calendar.SECOND,0);when.set(Calendar.MILLISECOND,0);
        if(when.getTimeInMillis()<=System.currentTimeMillis())when.add(Calendar.DAY_OF_YEAR,1);
        AlarmManager alarms=(AlarmManager)ctx.getSystemService(Context.ALARM_SERVICE);
        // Inexact repeating avoids exact-alarm special access and is kinder to battery.
        alarms.setInexactRepeating(AlarmManager.RTC_WAKEUP,when.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pending(ctx));
    }
    public static void cancel(Context ctx){
        ctx.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putBoolean("enabled",false).apply();
        AlarmManager manager=(AlarmManager)ctx.getSystemService(Context.ALARM_SERVICE);
        manager.cancel(pending(ctx));
    }
    public static void restore(Context context){
        SharedPreferences prefs=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        if(prefs.getBoolean("enabled",false))schedule(context,prefs.getString("time","19:00"));
    }
    @Override public void onReceive(Context context,Intent intent){
        if ("com.fluentme.coach.DAILY_REMINDER".equals(intent.getAction())) notifyNow(context);
    }
    public static void notifyNow(Context context){
        if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        createChannel(context);
        Intent start=new Intent(context,MainActivity.class);
        PendingIntent open=PendingIntent.getActivity(context,560,start,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,CHANNEL):new Notification.Builder(context);
        String[] prompts={
          "Try a few English sentences today. Small steps count!",
          "Your English journey is yours. Ready for a quick conversation?",
          "Every practice is useful. Try one new word today!",
          "Got 5 minutes? A little practice is valuable too.",
          "English time! Speak freely and learn from mistakes."
        };
        int day=Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
        Notification n=b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("FluentMe · A little English today?")
          .setContentText(prompts[day%prompts.length])
          .setAutoCancel(true).setContentIntent(open).build();
        ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify(110,n);
    }
}
