FluentMe · Voice-First English Coach (no Guided mode)

WHAT WORKS
- AI-only speaking/text chat through the existing Cloudflare Worker.
- Turn-by-turn spoken exchanges with supported microphone recognition and spoken replies.
- Older conversation turns (last 20) sent to AI, and history kept on device.
- Personal learning notes, Sinhala error feedback, practice and journey tracking.
- Normal sized fonts (chat 14px, body 15-16px), up to 60-minute daily goal.

IMPORTANT
- This is NOT Gemini Live real-time streaming. Browser listening after speaking depends on device and permission. Android wrapper uses tap-to-talk per turn.
- No installable APK is included; Android Studio project requires building on computer.
- The AI server may hit daily free quota. This is not an unlimited free AI service.

SETUP FROM ANDROID PHONE
1. EXPORT BACKUP from your previous FluentMe version before opening a different HTML file (local browser storage may differ).
2. Open FluentMe_AI_Voice_Only.html. Go Settings; enter your same Workers HTTPS URL and private COACH_ACCESS_CODE. Test connection.
3. On existing Cloudflare Worker, replace worker.js with FluentMe_AI_Voice_Only_Worker.js and Deploy. AI binding & secret stay as they are.
4. Coach -> Start speaking; allow microphone permission. Turn on auto-listen if the browser supports it. You can type instead.
5. IMPORT your previous backup, if needed.

SECURITY
Never paste access code into shared chats; keep it private. Avoid sensitive information in learning notes.
Chat content sent to your Cloudflare AI backend; your device saves the progress separately.
